a=12
b=13
print(a+b)